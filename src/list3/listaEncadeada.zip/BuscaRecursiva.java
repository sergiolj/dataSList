package list3;

public class BuscaRecursiva {
    public static void main(String[] args) {

    }

}
