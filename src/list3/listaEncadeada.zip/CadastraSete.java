package list3;

import list3.menu.MenuSevenElements;

public class CadastraSete {
    public static void main(String[] args) {
        var menu = new MenuSevenElements();
        menu.mainMenu();
    }
}
