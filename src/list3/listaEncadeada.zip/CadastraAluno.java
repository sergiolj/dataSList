package list3;

import list3.menu.MenuStudent;

public class CadastraAluno {
    public static void main(String[] args) {
        var menu = new MenuStudent();
        menu.mainMenu();
    }
}
