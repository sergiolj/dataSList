package list3;

import list3.menu.MenuNumInteger;

public class CadastraInteiro {
    public static void main(String[] args) {
        var menu = new MenuNumInteger();
        menu.mainMenu();
    }
}
