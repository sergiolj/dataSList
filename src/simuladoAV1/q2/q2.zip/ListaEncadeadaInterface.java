package simuladoAV1.q2;

public interface ListaEncadeadaInterface <T>{
    boolean adicionar(T elemento);
    boolean remover();
}
