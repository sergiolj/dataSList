package simuladoAV1.q3;

public class Main {
    public static void main(String[] args) {
        System.out.println(Potencia.calcularPotencia(2,2));
        System.out.println(Potencia.calcularPotencia(2,3));
        System.out.println(Potencia.calcularPotencia(2,4));
    }
}
