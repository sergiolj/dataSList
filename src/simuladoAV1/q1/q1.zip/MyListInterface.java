package simuladoAV1.q1;

public interface MyListInterface <T>{
    boolean add(T object);
    boolean remove(T object);
    boolean update(T object);
}
