package exercicesList;

public interface ITeacher {
    boolean addTeacher(Teacher teacher);
    boolean removeTeacher(Teacher teacher);
    void listTeacher();
    void alterTeacher(Teacher teacher);

}
