package exercicesList;

public interface IStudent {
    boolean addStudent(String student);
    boolean removeStudent(String student);
    boolean containsStudent(String student);
    int getSize();
    void deleteAllStudents();

}
