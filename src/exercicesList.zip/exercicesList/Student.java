package exercicesList;

import java.util.ArrayList;

public class Student implements IStudent {
    String name;
    String id;
    ArrayList<Student> students = new ArrayList<>();

    public Student(String name, String id) {
        this.name = name;
        this.id = id;
    }

    @Override
    public boolean addStudent(String student) {
        students.add(new Student(student,id));
        return false;
    }

    @Override
    public boolean removeStudent(String student) {
        return false;
    }

    @Override
    public boolean containsStudent(String student) {
        return false;
    }

    @Override
    public int getSize() {
        return 0;
    }

    @Override
    public void deleteAllStudents() {

    }
}
