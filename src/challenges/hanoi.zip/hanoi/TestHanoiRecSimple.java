package challenges.hanoi;

public class TestHanoiRecSimple {
    public static void main(String[] args) {
        HanoiRecSimple hs = new HanoiRecSimple(4);
        hs.solve();
    }
}
